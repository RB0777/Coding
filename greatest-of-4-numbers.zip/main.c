/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <stdio.h>

int main()
{
    int a, b,c, d;
scanf("%d%d%d%d",&a,&b,&c,&d);
if(a>b&&a>c&&a>d)
{
printf("a is greatest");
}
else if (b>a&&b>c&&b>d)
{
printf("b is greatest");
}
else if (c>a&&c>b&&c>d)
{
printf("c is greatest");
}
else 
{
    printf("d is greatest");
}
return 0;
}