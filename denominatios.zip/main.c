/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <stdio.h>
using namespace std;
int main()
{
    int a;
    scanf("%d",&a);
    if(a==1)
    {
        printf("The given denomination is 1 rupee coin/note");
    }
    else if(a==2)
    {
        printf("The given denomination is 2 rupee coin/note");
    }
    else if(a==5)
    {
        printf("The given denomination is 5 rupee coin/note");
    }
    else if(a==10)
    {
        printf("The given denomination is 10 rupee coin/note");
    }
    else if(a==20)
    {
        printf("The given denomination is 20 rupee note");
    }
    else if(a==50)
    {
        printf("The given denomination is 50 rupee note");
    }
    else if(a==100)
    {
        printf("The given denomination is 100 rupee note");
    }
    else if(a==500);
    {
        printf("The given denomination is 500 rupee note");
    }
    else if(a==2000)
    {
        printf("The given denomination is 2000 rupee note");
    }
        else if(a==200)
        {
            printf("The given denomination is 200 rupee note");
    }
    else 
    {
        printf("The given denomination is invalid");
    }
    return 0;
}


