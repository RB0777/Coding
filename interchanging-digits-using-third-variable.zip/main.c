/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <stdio.h>

int main()
{
    int a,b,c;
    scanf("%d",&a);
    printf("X=%d",&a);
    scanf("%d",&b);
    printf("Y=%d",&b);
    c=a;
    a=b;
    b=c;
printf("numbers interchanged");
printf("X=%d",&a);
printf("Y=%d",&b);
    return 0;
}
